
// Updated config with real email
window.BB_CONFIG = {
  phone: "+1 236-333-5632",
  email: "baharehsohrabi7@gmail.com",
  instagram: "https://instagram.com/your_insta_here",
  studioAddress: "Vancouver, BC",
  whatsAppNumberIntl: "12363335632",
  calendlyUrl: "", // e.g., https://calendly.com/yourname/service
  formspreeId: "your-form-id"
};
