
# Bahar Beauty — Static Website

A colorful, multi-page static site for **facials, makeup, and skincare** with affordable prices and booking options. Built to run on **GitHub Pages** (free, no custom domain required).

## Pages
- `index.html` — Home / hero + highlights
- `services.html` — Services list
- `pricing.html` — Transparent pricing & deals
- `gallery.html` — Image gallery (Unsplash images)
- `booking.html` — Booking form (Formspree) + WhatsApp/Call/Email buttons
- `contact.html` — Contact + map embed

## Quick Start (GitHub Pages)
1. Create a new GitHub repository named **bahar-beauty** (or any name).
2. Upload all files, or upload the provided ZIP and extract it in the repo.
3. In **Settings → Pages**, set Source to **Deploy from a branch**, then pick `main` branch and `/root` (or `docs` if you put files there).
4. Click Save — after a minute, your site will be live at:  
   `https://<your-username>.github.io/<repo-name>/`
5. If your pages don't load correctly, ensure links start with `/` or adjust to relative paths for subfolder hosting.

## Configure Your Info
Edit `assets/js/config.js`:
```js
window.BB_CONFIG = {
  phone: "+1 236-333-5632",
  email: "baharehsohrabi7@gmail.com",
  instagram: "https://instagram.com/your_insta_here",
  studioAddress: "Vancouver, BC",
  whatsAppNumberIntl: "12363335632",
  formspreeId: "your-form-id"
};
```
Also update the `action="https://formspree.io/f/your-form-id"` attribute in `booking.html` and `contact.html` **or** just set `formspreeId` above and the script will handle it.

> **Formspree (free tier)**: Create a form at [formspree.io](https://formspree.io) to receive booking messages by email without hosting a backend.

## Local Preview
Open `index.html` in your browser. For best results with map embeds, serve via a tiny local server:
- Python: `python3 -m http.server` then visit `http://localhost:8000`

## Customize Colors
Edit `assets/css/style.css` variables at the top to match your brand.

## License
All custom code in this template is MIT-licensed. Linked Unsplash images are under their respective licenses.


## Quick "Drop Link"
After you push to GitHub, your site will be live at:
```
https://<your-username>.github.io/<repo-name>/
```
Open `tools/github-pages-link.html` to generate your exact link.
